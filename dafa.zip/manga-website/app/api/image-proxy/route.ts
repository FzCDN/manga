import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const imageUrl = searchParams.get('url')

  if (!imageUrl) {
    return new NextResponse('Missing URL parameter', { status: 400 })
  }

  try {
    const response = await fetch(imageUrl)
    if (!response.ok) throw new Error('Failed to fetch image')

    const buffer = await response.arrayBuffer()
    const headers = new Headers(response.headers)
    headers.set('content-type', response.headers.get('content-type') || 'image/jpeg')
    headers.set('cache-control', 'public, max-age=31536000, immutable')

    return new NextResponse(buffer, {
      headers,
      status: 200,
    })
  } catch (error) {
    console.error('Image proxy error:', error)
    return new NextResponse('Failed to fetch image', { status: 500 })
  }
}

