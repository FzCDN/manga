import { Suspense } from "react"
import { SeriesContent } from "@/components/series-content"
import { SeriesSkeleton } from "@/components/skeleton/series-skeleton"
import { SiteHeader } from "@/components/site-header"
import { getSeriesDetails } from "@/utils/api"

export default async function SeriesPage({ params }: { params: { slug: string } }) {
  const mangaData = await getSeriesDetails(params.slug)
  return (
    <div className="min-h-screen bg-black">
      <SiteHeader />
      <main className="container max-w-4xl py-6">
        <Suspense fallback={<SeriesSkeleton />}>
          <SeriesContent slug={params.slug} />
        </Suspense>
      </main>
    </div>
  )
}

