/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: [
      'imgkub.com', 
      'manhwadesu.asia', 
      'baca02.manhwadesu.co.in',
      'go.belajarserver.xyz'
    ],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  }
}

module.exports = nextConfig

