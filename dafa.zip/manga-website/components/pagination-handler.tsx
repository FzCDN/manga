'use client'

import { useRouter } from 'next/navigation'
import { Pagination } from "@/components/pagination"

interface PaginationHandlerProps {
  currentPage: number
  hasNextPage: boolean
}

export function PaginationHandler({ currentPage, hasNextPage }: PaginationHandlerProps) {
  const router = useRouter()

  const handlePrevPage = () => {
    if (currentPage > 1) {
      router.push(`/page/${currentPage - 1}`)
    }
  }

  const handleNextPage = () => {
    if (hasNextPage) {
      router.push(`/page/${currentPage + 1}`)
    }
  }

  return (
    <Pagination 
      currentPage={currentPage}
      hasNextPage={hasNextPage}
      onPrevPage={handlePrevPage}
      onNextPage={handleNextPage}
    />
  )
}

