"use client"

import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface PaginationProps {
  currentPage: number
  hasNextPage: boolean
  onPrevPage: () => void
  onNextPage: () => void
}

export function Pagination({ currentPage, hasNextPage, onPrevPage, onNextPage }: PaginationProps) {
  return (
    <div className="flex items-center justify-center gap-4">
      <Button
        variant="outline"
        onClick={onPrevPage}
        disabled={currentPage === 1}
        className={cn(
          "px-4 py-2 rounded-lg bg-zinc-900/90 text-white",
          currentPage === 1 && "opacity-50 cursor-not-allowed"
        )}
      >
        <ChevronLeft className="h-4 w-4 mr-2" />
        PREV
      </Button>

      <Button
        variant="outline"
        onClick={onNextPage}
        disabled={!hasNextPage}
        className={cn(
          "px-4 py-2 rounded-lg bg-zinc-900/90 text-white",
          !hasNextPage && "opacity-50 cursor-not-allowed"
        )}
      >
        NEXT
        <ChevronRight className="h-4 w-4 ml-2" />
      </Button>
    </div>
  )
}

