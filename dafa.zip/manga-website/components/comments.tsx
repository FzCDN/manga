"use client"

import { useEffect } from 'react'

declare global {
  interface Window {
    DISQUS?: any;
  }
}

export function Comments() {
  useEffect(() => {
    const script = document.createElement('script')
    script.src = 'https://manhwa-desu.disqus.com/embed.js'
    script.setAttribute('data-timestamp', Date.now().toString())
    document.body.appendChild(script)

    return () => {
      document.body.removeChild(script)
    }
  }, [])

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-white">Comments</h2>
      <div id="disqus_thread"></div>
      <noscript>
        Please enable JavaScript to view the 
        <a href="https://disqus.com/?ref_noscript" rel="nofollow">
          comments powered by Disqus.
        </a>
      </noscript>
    </div>
  )
}

