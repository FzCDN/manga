export function getProxyImageUrl(url: string): string {
  // For development/testing, you might want to return the original URL
  if (process.env.NODE_ENV === 'development') {
    return url
  }

  // For production, proxy the image through our API
  return `/api/image-proxy?url=${encodeURIComponent(url)}`
}

