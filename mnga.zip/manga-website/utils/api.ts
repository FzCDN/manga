const API_KEY = "sigit"
const BASE_URL = "https://api-v2.agcprojects.com/api/v2/manga"

async function fetchWithTimeout(url: string, timeout = 5000) {
  const controller = new AbortController()
  const id = setTimeout(() => controller.abort(), timeout)

  try {
    const response = await fetch(url, {
      next: { revalidate: 3600 },
      headers: {
        'Accept': 'application/json'
      },
      signal: controller.signal
    })

    clearTimeout(id)

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    clearTimeout(id)
    // Error handled silently
    throw error
  }
}

export async function fetchLastUpdate(page: number = 1) {
  const url = page === 1
    ? "https://baca02.manhwadesu.co.in"
    : `https://baca02.manhwadesu.co.in/komik/page/${page}`
  const apiUrl = `${BASE_URL}/list?type=mangareader&apikey=${API_KEY}&url=${encodeURIComponent(url)}`

  try {
    const data = await fetchWithTimeout(apiUrl)
    if (!data.result || !Array.isArray(data.result)) {
      throw new Error('Invalid data format received from API')
    }
    return data.result
  } catch (error) {
    // Error handled silently
    return []
  }
}

export async function fetchPopular() {
  try {
    const allItems = await fetchLastUpdate()
    if (!allItems.length) return []
    const shuffled = [...allItems].sort(() => 0.5 - Math.random())
    return shuffled.slice(0, 10)
  } catch (error) {
    // Error handled silently
    return []
  }
}

export async function fetchFeaturedItems() {
  try {
    const allItems = await fetchLastUpdate()
    if (!allItems.length) return []
    const shuffled = [...allItems].sort(() => 0.5 - Math.random())
    return shuffled.slice(0, 5)
  } catch (error) {
    // Error handled silently
    return []
  }
}

export async function getSeriesDetails(slug: string) {
  if (!slug) throw new Error('Slug is required')
  
  const url = `${BASE_URL}/detail?type=mangareader&apikey=${API_KEY}&url=https://manhwadesu.asia/komik/${slug}/`

  try {
    const data = await fetchWithTimeout(url)
    if (!data.result) {
      throw new Error('Invalid data format received from API')
    }
    return data.result
  } catch (error) {
    // Error handled silently
    throw error
  }
}

export async function getChapterImages(slug: string, chapter: string) {
  if (!slug || !chapter) throw new Error('Slug and chapter are required')

  const chapterNumber = chapter.replace('chapter-', '')
  const url = `${BASE_URL}/chapter?type=mangareader&apikey=${API_KEY}&url=https://manhwadesu.asia/${slug}-chapter-${chapterNumber}/`

  try {
    const data = await fetchWithTimeout(url)
    if (!data.result) {
      throw new Error('Invalid data format received from API')
    }
    return data.result
  } catch (error) {
    // Error handled silently
    throw error
  }
}

export async function getChapterData(slug: string, chapter: string) {
  if (!slug || !chapter) throw new Error('Slug and chapter are required')

  try {
    const [chapterImages, seriesDetails] = await Promise.all([
      getChapterImages(slug, chapter),
      getSeriesDetails(slug)
    ])

    if (!seriesDetails.chapterList || !Array.isArray(seriesDetails.chapterList)) {
      throw new Error('Invalid chapter list format')
    }

    const chapterList = seriesDetails.chapterList
    const currentChapter = chapterList.find((c: any) => c.url.includes(chapter.replace('chapter-', '')))

    if (!currentChapter) {
      throw new Error('Current chapter not found')
    }

    const currentWeight = currentChapter.weight
    const prevChapter = chapterList.find((c: any) => c.weight === currentWeight - 1)
    const nextChapter = chapterList.find((c: any) => c.weight === currentWeight + 1)

    return {
      images: chapterImages,
      title: seriesDetails.title,
      chapter: currentChapter.title,
      seriesCover: seriesDetails.cover,
      chapterList: chapterList,
      currentChapter: chapter,
      prevChapter: prevChapter ? { title: prevChapter.title, url: prevChapter.url } : null,
      nextChapter: nextChapter ? { title: nextChapter.title, url: nextChapter.url } : null
    }
  } catch (error) {
    throw new Error('Failed to fetch chapter data')
  }
}

