"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { Grid2X2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Comments } from "@/components/comments"
import { BoxSkeleton } from "@/components/ui/box-skeleton"
import { Popular } from "@/components/popular"
import { fetchPopular } from "@/utils/api"
import { createChapterUrl } from "@/utils/url"

// Find the chapter with weight 0 (usually the first chapter) or default to the last chapter
const getFirstChapter = (chapterList: any[]) => {
  return chapterList.find(chapter => chapter.weight === 0) || chapterList[chapterList.length - 1];
}

export function SeriesContent({ slug }: { slug: string }) {
  const [searchTerm, setSearchTerm] = useState("")
  const [mangaData, setMangaData] = useState<any>(null)
  const [activeView, setActiveView] = useState<'chapters' | 'comments'>('chapters')
  const [isLoading, setIsLoading] = useState(true)
  const [popularItems, setPopularItems] = useState<any[]>([])

  useEffect(() => {
    setIsLoading(true)
    getMangaDetails(slug)
      .then(data => {
        setMangaData(data)
        setIsLoading(false)
      })
      .catch(error => {
        console.error("Error fetching manga details:", error)
        setIsLoading(false)
      })
  }, [slug])

  useEffect(() => {
    fetchPopular().then(items => setPopularItems(items))
  }, [])

  if (isLoading) {
    return <BoxSkeleton className="h-[600px] w-full" />
  }

  if (!mangaData) {
    return notFound()
  }

  const { result } = mangaData

  const filteredChapters = result.chapterList
    .slice()
    .reverse()
    .filter((chapter: any) => 
      chapter.title.toLowerCase().includes(searchTerm.toLowerCase())
    )

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <div className="relative aspect-[4/3] md:aspect-[16/9] mb-4 overflow-hidden rounded-xl">
          <Image
            src={result.cover}
            alt={result.title}
            fill
            className="object-cover"
            priority
          />
        </div>
        <h1 className="text-2xl font-bold text-white mb-4">
          {result.title}
        </h1>
        <div className="flex flex-wrap gap-2 mb-4">
          {result.genres.map((genre: string) => (
            <Badge
              key={genre}
              variant="secondary"
              className="bg-zinc-800 text-white hover:bg-zinc-700"
            >
              {genre}
            </Badge>
          ))}
        </div>
        <p className="text-sm text-zinc-400 mb-6">
          {result.description}
        </p>
        <div className="flex gap-4">
          <Link href={createChapterUrl(result.link, getFirstChapter(result.chapterList).url)}>
            <Button size="lg" className="flex-1 md:flex-none">
              Read Now
            </Button>
          </Link>
          <Button size="lg" variant="outline" className="flex-1 md:flex-none">
            Add To
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <Button
            variant="secondary"
            onClick={() => setActiveView(activeView === 'chapters' ? 'comments' : 'chapters')}
            className="text-xl font-semibold text-white bg-zinc-900 hover:bg-zinc-800"
          >
            {activeView === 'chapters' ? 'Comments' : 'Chapters'}
          </Button>
          {activeView === 'chapters' && (
            <div className="flex items-center gap-2">
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Filter Chapter..."
                  className="w-[200px] bg-zinc-900 border-zinc-800 text-white placeholder:text-zinc-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 rounded-lg bg-zinc-900"
              >
                <Grid2X2 className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        {activeView === 'chapters' ? (
          <div className="space-y-2">
            {filteredChapters.map((chapter: any) => (
              <div
                key={chapter.weight}
                className="flex items-center justify-between gap-4 rounded-lg bg-zinc-900 p-4"
              >
                <div className="space-y-1">
                  <h3 className="font-medium text-white">
                    {chapter.title}
                  </h3>
                  <p className="text-sm text-zinc-400">{result.title}</p>
                </div>
                <div className="flex items-center gap-4">
                  <Link href={createChapterUrl(result.link, chapter.url)}>
                    <Button variant="secondary" className="w-24">
                      Read
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Comments />
        )}
        <Popular items={popularItems} />
      </div>
    </div>
  )
}

async function getMangaDetails(slug: string) {
  const apiKey = "sigit"
  const url = `https://api-v2.agcprojects.com/api/v2/manga/detail?type=mangareader&apikey=${apiKey}&url=https://manhwadesu.asia/komik/${slug}/`
  
  const res = await fetch(url, { next: { revalidate: 3600 } })
  
  if (!res.ok) {
    throw new Error('Failed to fetch manga details')
  }
  
  return res.json()
}

