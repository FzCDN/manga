import { Skeleton } from "@/components/ui/skeleton"

export function MangaGridSkeleton() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="space-y-2">
          <div className="relative aspect-[3/4] w-full">
            <Skeleton className="absolute inset-0 rounded-lg" />
            <div className="absolute bottom-2 right-2">
              <Skeleton className="h-6 w-16" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Skeleton className="h-2 w-2 rounded-full" />
            <Skeleton className="h-4 w-full" />
          </div>
        </div>
      ))}
    </div>
  )
}

