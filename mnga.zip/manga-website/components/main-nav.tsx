import Link from "next/link"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

const navItems = [
  { title: "webAPP Komiku", href: "/webapp" },
  { title: "Beranda", href: "/" },
  { title: "Terbaru", href: "/terbaru" },
  { title: "Daftar Komik", href: "/daftar" },
  { title: "8Kaijuu", href: "/8kaijuu" },
  { title: "Isekai", href: "/isekai" },
  { title: "Fantasy", href: "/fantasy" },
  { title: "Rak Buku", href: "/rakbuku" },
]

export function MainNav() {
  return (
    <nav className="border-b bg-background">
      <div className="container flex h-14 items-center">
        <div className="flex gap-2">
          {navItems.map((item, index) => (
            <Button
              key={item.href}
              variant={index === 0 ? "default" : "ghost"}
              asChild
              className={cn(
                "h-9",
                index === 0 && "bg-blue-600 hover:bg-blue-700"
              )}
            >
              <Link href={item.href}>{item.title}</Link>
            </Button>
          ))}
        </div>
      </div>
    </nav>
  )
}

