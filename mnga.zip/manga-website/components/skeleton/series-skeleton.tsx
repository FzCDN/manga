import { BoxSkeleton } from "@/components/ui/box-skeleton"

export function SeriesSkeleton() {
  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <BoxSkeleton className="h-[300px] w-full rounded-xl" />
        <BoxSkeleton className="h-8 w-3/4" />
        <div className="flex flex-wrap gap-2">
          {[...Array(5)].map((_, i) => (
            <BoxSkeleton key={i} className="h-6 w-20" />
          ))}
        </div>
        <BoxSkeleton className="h-20 w-full" />
        <div className="flex gap-4">
          <BoxSkeleton className="h-10 w-28" />
          <BoxSkeleton className="h-10 w-28" />
        </div>
      </div>
      <div className="space-y-4">
        <div className="flex justify-between">
          <BoxSkeleton className="h-8 w-24" />
          <BoxSkeleton className="h-8 w-40" />
        </div>
        {[...Array(5)].map((_, i) => (
          <BoxSkeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    </div>
  )
}

