"use client"

import * as React from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

const tabs = [
  {
    id: "newest",
    label: "NEWEST"
  },
  {
    id: "popular",
    label: "POPULAR"
  },
  {
    id: "completed",
    label: "COMPLETED"
  }
]

export function AnimeTabs() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const currentTab = searchParams.get("tab") || "newest"

  return (
    <Tabs value={currentTab} onValueChange={(value) => router.push(`/?tab=${value}`, { scroll: false })}>
      <TabsList className="bg-card border">
        {tabs.map((tab) => (
          <TabsTrigger
            key={tab.id}
            value={tab.id}
            className={cn(
              "data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            )}
          >
            {tab.label}
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  )
}

