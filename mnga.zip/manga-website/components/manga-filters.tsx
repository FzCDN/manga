import { Button } from "@/components/ui/button"

export function MangaFilters() {
  return (
    <div className="container py-6">
      <h2 className="text-xl font-semibold mb-4">Filter Komik:</h2>
      <div className="flex gap-4">
        <Button variant="outline" size="lg">
          MANGA
        </Button>
        <Button variant="outline" size="lg">
          MANHUA
        </Button>
        <Button variant="outline" size="lg">
          MANHWA
        </Button>
      </div>
    </div>
  )
}

