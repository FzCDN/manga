import { Skeleton } from "@/components/ui/skeleton"

export function FeaturedSliderSkeleton() {
  return (
    <div className="relative overflow-hidden rounded-lg">
      <Skeleton className="aspect-[9/6] w-full" />
      <div className="absolute inset-0 flex flex-col justify-end p-6 space-y-4">
        <Skeleton className="h-8 w-3/4" />
        <Skeleton className="h-10 w-32" />
      </div>
    </div>
  )
}

